/* main.js — HVAC Template */

// ── Year in footer
document.querySelectorAll('#year').forEach(el => {
  el.textContent = new Date().getFullYear();
});

// ── Sticky header shadow
const header = document.getElementById('header');
if (header) {
  window.addEventListener('scroll', () => {
    header.classList.toggle('scrolled', window.scrollY > 10);
  });
}

// ── Mobile nav toggle
const navToggle = document.getElementById('navToggle');
const nav = document.getElementById('nav');
if (navToggle && nav) {
  navToggle.addEventListener('click', () => {
    const open = nav.classList.toggle('open');
    navToggle.setAttribute('aria-expanded', open);
  });
}

// ── Fade-in on scroll (IntersectionObserver)
const fadeEls = document.querySelectorAll(
  '.service-card, .why-card, .testimonial, .value-card, .team-card, .service-detail'
);
if ('IntersectionObserver' in window && fadeEls.length) {
  fadeEls.forEach(el => el.classList.add('fade-in'));
  const obs = new IntersectionObserver((entries) => {
    entries.forEach(e => {
      if (e.isIntersecting) {
        e.target.classList.add('visible');
        obs.unobserve(e.target);
      }
    });
  }, { threshold: 0.1 });
  fadeEls.forEach(el => obs.observe(el));
}

// ── Contact form (placeholder — wire up to your backend/Formspree/etc.)
const contactForm = document.getElementById('contactForm');
if (contactForm) {
  contactForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const btn = contactForm.querySelector('[type="submit"]');
    btn.textContent = 'Sending…';
    btn.disabled = true;

    // Replace with real form submission logic:
    // e.g. fetch('/api/contact', { method: 'POST', body: new FormData(contactForm) })

    setTimeout(() => {
      btn.textContent = 'Enquiry Sent ✓';
      btn.style.background = '#1a8a4a';
    }, 1200);
  });
}
