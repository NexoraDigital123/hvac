# HVAC Template — Setup & Customisation Guide

A production-ready, multi-page website template for HVAC and industrial air solution companies.
Modelled on the A.D Air Solutions site structure. Static HTML/CSS/JS — no build tools required.

---

## File Structure

```
hvac-template/
├── index.html          ← Home page
├── about.html          ← About / Team page
├── services.html       ← Services detail page
├── contact.html        ← Contact + enquiry form
├── vercel.json         ← Vercel deployment config
└── assets/
    ├── style.css       ← All styles (design tokens at top)
    ├── main.js         ← Nav, animations, form handling
    └── images/         ← Add your images here (see list below)
```

---

## Quick Start (Deploy to Vercel)

1. Upload this folder to a GitHub repo
2. Connect repo to Vercel (vercel.com/new)
3. Vercel auto-detects static site — hit Deploy
4. Done. Custom domain can be added in Vercel settings.

---

## Customisation Checklist

### 1. Brand / Company details
Search and replace all `[COMPANY]`, `[COMPANY NAME]`, `[domain]` placeholders across all HTML files.

| Placeholder        | Replace with                        |
|--------------------|-------------------------------------|
| `[COMPANY]`        | Short company name e.g. `ProAir`    |
| `[COMPANY NAME]`   | Full legal name                     |
| `[domain]`         | Domain e.g. `proair`                |
| `[REGION]`         | Service region e.g. `KZN`           |
| `[LOCATION]`       | City / suburb e.g. `Westmead`       |
| `[Main Line]`      | Primary phone number                |
| `[Number]`         | 24hr emergency number               |
| `[Street Address]` | Physical address                    |
| `[OEM BRAND]`      | e.g. `Atlas Copco`                  |

### 2. Colours (assets/style.css — top of file)
```css
:root {
  --accent: #e8600a;   /* ← Change to your brand colour */
}
```

### 3. Images (place in assets/images/)
| Filename           | Usage                      | Recommended size |
|--------------------|----------------------------|------------------|
| about-photo.jpg    | About section photo        | 800×600px        |
| gallery-1.jpg      | Compressors gallery        | 900×600px        |
| gallery-2.jpg      | Turnkey projects           | 600×400px        |
| gallery-3.jpg      | Ducting                    | 600×400px        |
| gallery-4.jpg      | HVAC                       | 600×400px        |
| gallery-5.jpg      | Generators                 | 600×400px        |
| team-1/2/3.jpg     | Team member photos         | 400×400px        |

Use free stock photos from Unsplash (unsplash.com) or your own project photos.

### 4. Logo
Replace the SVG logo mark in `header` → `.logo__mark` across all pages,
or add an `<img>` tag pointing to your logo file:
```html
<div class="logo__mark">
  <img src="assets/images/logo.svg" alt="[COMPANY] logo" width="36" height="36" />
</div>
```

### 5. Contact Form
Wire up the form in `assets/main.js`. Options:
- **Formspree**: `action="https://formspree.io/f/YOUR_ID"` on the form
- **Netlify Forms**: add `data-netlify="true"` to the form
- **Custom API**: replace the `setTimeout` in main.js with a `fetch()` call

### 6. Google Maps Embed (contact.html)
Replace `[LATITUDE],[LONGITUDE]` in the iframe src with actual coordinates.

### 7. Social links
Update the Facebook / Instagram / LinkedIn `href` attributes in `index.html` footer.

### 8. OEM Partner Logos
Replace `.oem-logo-placeholder` divs with actual `<img>` tags.

### 9. Add more pages
Copy `services.html` as a starting point. Update nav `active` class on each page.

---

## Adding/Removing Services
Services are in two places:
- `index.html` → `.services-grid` (card grid)
- `services.html` → `.services-list` (detail view)

Each service card links to an `#anchor` on services.html.

---

## Typography
Using Google Fonts:
- **Headings**: Barlow Condensed (800 weight)
- **Body**: Barlow (400/500/600)

To change fonts, update the `<link>` in `<head>` and `:root` font variables in style.css.

---

## Browser Support
Chrome, Firefox, Safari, Edge — all modern browsers. IE not supported.

---

## Licence
Template is free to use and modify for client projects.
